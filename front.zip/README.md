# EpicGameStoreFront

actualizado por sebas

Actualizado por Eric

actualizado por Jeffrey

actualizado por Ale(prueba-martes4)

Actualizado por Alexx.

http://localhost:3001/admin/videogames?status=banned
http://localhost:3001/admin/videogames?sellerId=
http://localhost:3001/admin/videogames

arreglar ruta de login, verificar si esta en false--------------->
