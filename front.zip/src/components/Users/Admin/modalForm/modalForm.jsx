
const ModalForm = () => {
    return (
        <div>hola soy modalForm</div>
    )
}

export default ModalForm